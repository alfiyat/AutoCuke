package stepDefination;





import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



import pageFactory.HomePage;
import commonProperties.BrowserSetup;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserInterfaceTest extends BrowserSetup{
	
	
	@Given("^Open Chrome and start application$")
	public void open_Chrome_and_start_application() throws Throwable {
		init();
		driver.get(prop.getProperty("URL"));
	}

	@Then("^Landing page title is UI Testing Site$")
	public void landing_page_title_is_UI_Testing_Site() throws Throwable {
		HomePage home = new HomePage(driver);
	 //String title = 
	 Assert.assertEquals("UI Testing Site", home.getHomePageTitle());
	}

	@When("^User navigates to Home page$")
	public void user_navigates_to_Home_page() throws Throwable {
		driver.findElement(By.id("form")).click();
	   
	}

	@Then("^Home page title is UI Testing Site$")
	public void home_page_title_is_UI_Testing_Site() throws Throwable {
		 String title = driver.getTitle();
		 Assert.assertEquals("UI Testing Site", title);  
		 driver.close();
	}


}
