package pageFactory;

import org.openqa.selenium.WebDriver;

import commonProperties.CustomMethodsClass;

public class HomePage extends CustomMethodsClass {
	
	WebDriver driver;
	String title;
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public String getHomePageTitle()
	{
		String title = getPageTitle(driver);
				return title;
	}

}
