package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import commonProperties.Base;
import commonProperties.CustomMethodsClass;

public class HomePage extends Base {

	String homePageURL = "http://uitest.duodecadits.com/";
	String linkText = "Home";
	CustomMethodsClass cmc = new CustomMethodsClass();

	By homeButton = By.id("home");
	By formButton = By.id("form");
	By companyLogo = By.id("dh_logo");

	public HomePage(WebDriver driver) {
		super(driver);
	}

	public String getHomePageURL() {
		return homePageURL;
	}

	public void setHomePageURL(String homePageURL) {
		this.homePageURL = homePageURL;
	}

	public String getHomePageTitle() {
		return (cmc.getPageTitle(driver));
	}

	public boolean isCompanyLogoVisible() {
		return (cmc.isDispalyedOnPage(driver, companyLogo));
	}

	public void clickOnHomeButton() {
		cmc.click(driver, homeButton);
	}

	public boolean isHomeButtonActive() {
		return (cmc.isButtonActive(driver, linkText));
	}

	public boolean ish1TextVisible(String text) {
		return (cmc.geth1TagText(driver, text));

	}

	public boolean ispTextVisible(String text) {
		return (cmc.getpTagText(driver, text));
	}

	public Object isUserOnHomePage() {
		if (driver.getCurrentUrl().contains(getHomePageURL())) {
			return true;
		} else {
			return false;
		}
	}

	public FormPage navigateToFormSite() {
		cmc.click(driver, formButton);
		return new FormPage(driver);

	}

}
