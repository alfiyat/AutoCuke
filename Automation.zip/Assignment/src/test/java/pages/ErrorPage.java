package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import commonProperties.Base;
import commonProperties.CustomMethodsClass;

public class ErrorPage extends Base {

	By companyLogo = By.id("dh_logo");
	CustomMethodsClass cmc = new CustomMethodsClass();

	public ErrorPage(WebDriver driver) {
		super(driver);
	}

	public Object getErrorPageTitle() {
		return (cmc.getPageTitle(driver));
	}

	public boolean isCompanyLogoVisible() {
		return (cmc.isDispalyedOnPage(driver, companyLogo));

	}

	public boolean is404HTTPResponseCode() {
		return (cmc.isResponseCodeVisible(driver));
	}

}
