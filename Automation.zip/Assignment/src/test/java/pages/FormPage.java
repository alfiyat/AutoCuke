package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import commonProperties.Base;
import commonProperties.CustomMethodsClass;

public class FormPage extends Base {

	String formPageURL = "http://uitest.duodecadits.com/form.html";
	String linkText = "Form";
	CustomMethodsClass cmc = new CustomMethodsClass();
	By errorButton = By.id("error");
	By companyLogo = By.id("dh_logo");
	By inputBox = By.xpath("//input[@type='text']");
	By submitButton = By.xpath("//button[@type='submit']");
	By helloText = By.id("hello-text");

	public FormPage(WebDriver driver) {
		super(driver);
	}

	public String getFormPageURL() {
		return formPageURL;
	}

	public void setFormPageURL(String formPageURL) {
		this.formPageURL = formPageURL;
	}

	public String getFormPageTitle() {
		return (cmc.getPageTitle(driver));
	}

	public boolean isCompanyLogoVisible() {
		return (cmc.isDispalyedOnPage(driver, companyLogo));
	}

	public boolean isFormButtonActive() {
		return (cmc.isButtonActive(driver, linkText));
	}

	public boolean isInputBoxVisible() {
		return (cmc.isInputBoxElement(driver, inputBox));
	}

	public boolean isSubmitButtonVisible() {
		return (cmc.isSubmitButtonElement(driver, submitButton));

	}

	public void enterData(String value) {
		cmc.enterDataInBox(driver, inputBox, value);

	}

	public void clickOnSubmitButton() {
		cmc.click(driver, submitButton);

	}

	public String getOutputData() {
		return (cmc.getResultData(driver, helloText));
	}

	public ErrorPage navigateToErrorSite() {

		cmc.click(driver, errorButton);
		return new ErrorPage(driver);
	}

}
