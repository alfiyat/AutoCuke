package glue;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Assert;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pages.ErrorPage;
import pages.FormPage;
import pages.HomePage;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Steps {

	WebDriver driver;
	HomePage homePageObj;
	FormPage formPageObj;
	ErrorPage errorPageObj;
	Logger logger;

	@Before
	public void setUp() {
		logger=Logger.getLogger("Steps");
	    PropertyConfigurator.configure("Log4j.properties");
		System.setProperty("webdriver.chrome.driver",
				"../Assignment/src/test/resources/driver/chromedriver.exe");
		driver = new ChromeDriver();
		logger.info("Browser is open");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Given("^User is on UI Testing Site$")
	public void user_is_on_site() throws Throwable {

		homePageObj = new HomePage(driver);
		homePageObj.navigateToSite();
		logger.info("On home page");
		driver.manage().window().maximize();
	}

	@Then("^Home page title is \"([^\"]*)\"$")
	public void home_page_title_is(String sitePageTitle) throws Throwable {
		Assert.assertEquals("The title of Home page is not UI Testing Site",
				sitePageTitle, homePageObj.getHomePageTitle());
	}

	@When("^User click on the Form button$")
	public void user_click_on_the_Form_button() throws Throwable {
		formPageObj = homePageObj.navigateToFormSite();
	}

	@Then("^Form page title is \"([^\"]*)\"$")
	public void form_page_title_is(String sitePageTitle) throws Throwable {
		Assert.assertEquals("The title of Form page is not UI Testing Site",
				sitePageTitle, formPageObj.getFormPageTitle());

	}

	@When("^User click on the Error button$")
	public void user_click_on_the_Error_button() throws Throwable {
		formPageObj = new FormPage(driver);
		errorPageObj = formPageObj.navigateToErrorSite();
	}

	@Then("^Error page title is \"([^\"]*)\"$")
	public void error_page_title_is(String siteErrorTitle) throws Throwable {
		Assert.assertEquals("The title of Error page is not UI Testing Site",
				siteErrorTitle, errorPageObj.getErrorPageTitle());

	}

	@Then("^Check company logo is present on Home page$")
	public void check_company_logo_is_present_on_Home_page() throws Throwable {
		Assert.assertEquals("Company logo is not visible on home page", true,
				homePageObj.isCompanyLogoVisible());

	}

	@Then("^Check company logo is present on Form page$")
	public void check_company_logo_is_present_on_Form_page() throws Throwable {
		Assert.assertEquals("Company logo is not visible on form page", true,
				formPageObj.isCompanyLogoVisible());

	}

	@Then("^Check company logo is present on Error page$")
	public void check_company_logo_is_present_on_Error_page() throws Throwable {
		Assert.assertEquals("Company logo is not visible on error page", true,
				errorPageObj.isCompanyLogoVisible());

	}

	@When("^User click on the Home button$")
	public void user_click_on_the_Home_button() throws Throwable {
		homePageObj.clickOnHomeButton();
	}

	@Then("^User navigated to Home Page$")
	public void user_navigated_to_Home_Page() throws Throwable {
		Assert.assertEquals(
				"Although clicked on Home button, user is not on home page",
				true, homePageObj.isUserOnHomePage());
	}

	@Then("^Home button turned to active status$")
	public void home_button_turned_to_active_status() throws Throwable {
		Assert.assertTrue("Home button is not turned to active status",
				homePageObj.isHomeButtonActive());
	}

	@Then("^User navigated to Form Page$")
	public void user_navigated_to_Form_Page() throws Throwable {
		Assert.assertEquals(
				"Although clicked on Form button, user is not on Form page",
				formPageObj.getFormPageURL(), driver.getCurrentUrl());
	}

	@Then("^Form button turned to active status$")
	public void form_button_turned_to_active_status() throws Throwable {
		Assert.assertTrue("Form button is not turned to active status",
				formPageObj.isFormButtonActive());
	}

	@When("^User click on the UI Testing button$")
	public void user_click_on_the_UI_Testing_button() throws Throwable {
		Assert.assertEquals(
				"Although clicked on UI Testing button, user is not on home page",
				homePageObj.getHomePageURL(), driver.getCurrentUrl());

	}

	@Then("^The text \"([^\"]*)\" is visible on the Home page in h1 tag$")
	public void the_text_is_visible_on_the_Home_page_in_h1_tag(String h1TagText)
			throws Throwable {

		Assert.assertEquals("h1 tag text is not visible on home page", true,
				homePageObj.ish1TextVisible(h1TagText));
	}

	@Then("^The text \"([^\"]*)\" visible on the Home page in p tag$")
	public void the_text_visible_on_the_Home_page_in_p_tag(String pTagText)
			throws Throwable {
		Assert.assertEquals("p tag text is not visible on home page", true,
				homePageObj.ispTextVisible(pTagText));

	}

	@Then("^Form is visible with one input box$")
	public void form_is_visible_with_one_input_box() throws Throwable {
		Assert.assertEquals("A Input Box is not visible on form page", true,
				formPageObj.isInputBoxVisible());
	}

	@Then("^Form is visible with one submit button$")
	public void form_is_visible_with_one_submit_button() throws Throwable {
		Assert.assertEquals("A Submit Button is not visible on form page",
				true, formPageObj.isSubmitButtonVisible());
	}

	@When("^User types \"([^\"]*)\" in input field$")
	public void user_types_in_input_field(String value) throws Throwable {
		formPageObj.enterData(value);
	}

	@And("^Cliks on submit button$")
	public void cliks_on_submit_button() throws Throwable {
		formPageObj.clickOnSubmitButton();
	}

	@And("^On page text appeared as: \"([^\"]*)\"$")
	public void on_page_text_appeared_as(String result) throws Throwable {
		Assert.assertEquals("The output data is not as expected", result,
				formPageObj.getOutputData());

	}

	@Then("^User is getting a 404 HTTP response code$")
	public void user_is_getting_a_404_HTTP_response_code() throws Throwable {
		Assert.assertEquals(
				"A 404 HTTP response code is not visible on error page", true,
				errorPageObj.is404HTTPResponseCode());

	}

	@After
	public void tearDown(Scenario scenario) {
		scenario.write("Finished Scenario");
		if (scenario.isFailed()) {
			scenario.embed(((TakesScreenshot) driver)
					.getScreenshotAs(OutputType.BYTES), "image/png");
		}

		driver.close();	
		logger.info("Window closed!!");
	}
}
