package commonProperties;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CustomMethodsClass {
	
	public String getPageTitle(WebDriver driver)
	{
		String title = driver.getTitle();
		return title;
	}
	
//	WebDriverWait webDriverWait = null;
//	
//	public void implicitWait(WebDriver driver, long timeOut) {
//		driver.manage().timeouts().implicitlyWait(timeOut, TimeUnit.SECONDS);
//	}
//	// Wait<WebDriver> wait;
//				// wait = new FluentWait<WebDriver>(driver).withTimeout(20,
//			// TimeUnit.SECONDS).pollingEvery(5,
//			// TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
//
//
//	public void  waitUntilPresenceOfElementLocated(WebDriver driver,By by, long timeOut){
//		webDriverWait = new WebDriverWait(driver, timeOut);
//	    webDriverWait.until(ExpectedConditions.presenceOfElementLocated(by));
//	}
//	
//	public void  waitUntilTextToBePresent(WebDriver driver,By by, long timeOut, String text){
//		webDriverWait = new WebDriverWait(driver, timeOut);
//	    webDriverWait.until(ExpectedConditions.textToBePresentInElementValue(by, text));
//	}
//	
//	public void waitUntilElementToBeClickable(WebDriver driver,
//			By by, long timeOut) {
//		webDriverWait =  new WebDriverWait(driver, timeOut);
//		webDriverWait.until(ExpectedConditions.elementToBeClickable(by));
//		
//	}
//	
//	public void enterValue(WebDriver driver, By by, String value) {
//		try {
//			driver.findElement(by).clear();
//			driver.findElement(by).sendKeys(value);
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//
//	}
//
//	public void click(WebDriver driver, By by) {
//		try {
//			driver.findElement(by).click();
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//
//	}
//
//	public boolean isDispalyedOnPage(WebDriver driver, By by) {
//		try {
//			driver.findElement(by).isDisplayed();
//			return true;
//		} catch (Exception e) {
//			return false;
//		}
//	}
//	public boolean isElementEnabled(WebDriver driver, By by) {
//		try {
//			driver.findElement(by).isEnabled();
//			return true;
//		} catch (Exception e) {
//			return false;
//		}
//	}
//	
//	public String getTextOfValidationMSG(WebDriver driver, By by) {
//		try{
//			String msg = driver.findElement(by).getText();
//			return msg;
//		}catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//		return null;
//	}

}
