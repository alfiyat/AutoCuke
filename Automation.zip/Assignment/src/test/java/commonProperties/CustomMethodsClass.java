package commonProperties;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CustomMethodsClass {

	WebDriverWait webDriverWait = null;
	List<WebElement> activeListElements = null;
	List<WebElement> activeLinks = null;
	List<WebElement> h1TagElements = null;
	List<WebElement> pTagElements = null;
	String actualHrefText = null;

	public String getPageTitle(WebDriver driver) {
		return (driver.getTitle());
	}

	public void waitUntilElementToBeClickable(WebDriver driver, By by,
			long timeOut) {
		webDriverWait = new WebDriverWait(driver, timeOut);
		webDriverWait.until(ExpectedConditions.elementToBeClickable(by));

	}

	public void click(WebDriver driver, By by) {
		try {
			waitUntilElementToBeClickable(driver, by, 10);
			driver.findElement(by).click();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public boolean isDispalyedOnPage(WebDriver driver, By by) {
		try {
			driver.findElement(by).isDisplayed();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean isButtonActive(WebDriver driver, String linkText) {
		try {
			activeListElements = driver.findElements(By.className("active"));
			for (WebElement activeWebElement : activeListElements) {
				activeLinks = activeWebElement.findElements(By.tagName("a"));

				for (int i = 0; i < activeLinks.size(); i++) {
					actualHrefText = activeLinks.get(i).getText();

					if (actualHrefText.equalsIgnoreCase(linkText)) {

						return true;
					}
				}
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	public boolean geth1TagText(WebDriver driver, String h1Text) {
		try {
			h1TagElements = driver.findElements(By.tagName("h1"));
			for (int i = 0; i < h1TagElements.size(); i++) {
				if (h1TagElements.get(i).getText().equalsIgnoreCase(h1Text)) {
					return true;
				}
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	public boolean getpTagText(WebDriver driver, String pText) {
		try {
			pTagElements = driver.findElements(By.tagName("p"));
			for (int i = 0; i < pTagElements.size(); i++) {
				if (pTagElements.get(i).getText().equalsIgnoreCase(pText)) {
					return true;
				}
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	public boolean isInputBoxElement(WebDriver driver, By inputBox) {
		try {
			if (driver.findElements(inputBox).size() == 1) {
				return true;
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	public boolean isSubmitButtonElement(WebDriver driver, By submitButton) {
		try {
			if (driver.findElements(submitButton).size() == 1) {
				return true;
			}
		} catch (Exception e) {
			return false;
		}
		return false;
	}

	public void enterDataInBox(WebDriver driver, By by, String value) {
		try {
			driver.findElement(by).clear();
			driver.findElement(by).sendKeys(value);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public String getResultData(WebDriver driver, By by) {
		try {
			return (driver.findElement(by).getText());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

	public boolean isResponseCodeVisible(WebDriver driver) {
		try {
			if (driver.getPageSource().equalsIgnoreCase(
					"404 Error: File not found"))
				;
			{
				return true;
			}
		} catch (Exception e) {
			return false;
		}

	}
}
