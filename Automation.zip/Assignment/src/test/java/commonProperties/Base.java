package commonProperties;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;

import pages.HomePage;

public class Base {

	protected WebDriver driver;
	public static Properties prop;

	public Base(WebDriver driver) {
		this.driver = driver;
	}

	public void getConfigData() throws IOException {
		prop = new Properties();
		File file = new File(System.getProperty("user.dir")
				+ "\\src\\test\\resources\\Config.properties");
		FileReader reader = new FileReader(file);
		prop.load(reader);
	}

	public HomePage navigateToSite() throws IOException {
		getConfigData();
		driver.get(prop.getProperty("URL"));
		return new HomePage(driver);
	}
	
}
