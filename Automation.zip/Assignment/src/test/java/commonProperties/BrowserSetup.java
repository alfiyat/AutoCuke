package commonProperties;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BrowserSetup {

	public static Properties prop;
	public WebDriver driver = null;

	public void getConfigData() throws IOException {
		prop = new Properties();
		File file = new File(System.getProperty("user.dir")
				+ "\\src\\test\\resources\\Config.properties");
		FileReader reader = new FileReader(file);
		prop.load(reader);
	}

	public void Chromebrowser() throws Exception {

//		ChromeOptions options = new ChromeOptions();
//		Map<String, Object> prefs = new HashMap<String, Object>();
//		prefs.put("credentials_enable_service", false);
//		options.setExperimentalOption("prefs", prefs);

		System.setProperty("webdriver.chrome.driver",
				prop.getProperty("ChromeDriver"));
		driver = new ChromeDriver();
		System.out.println(driver+"in setup");
		Thread.sleep(30000);
		driver.manage().window().maximize();
	}

	public void init() throws Exception {
		getConfigData();
		Chromebrowser();
	}

}
