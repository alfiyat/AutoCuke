package com.crud.automation.customproperties;

import org.openqa.selenium.WebDriver;

public class Constants {
	public  WebDriver driver=null;
	public final String ChromeDriver = "C:\\Users\\driver\\chromedriver.exe";
	public final String URL = "https://halo-new-int.mobgen.com";
	public String un = "test.admin@assignment.com";
	public String pwd = "aA12345*";
}

