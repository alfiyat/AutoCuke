package com.crud.automation.customproperties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class BrowserSetup {
	
	public void Chromebrowser(Constants constants) throws Exception{    
//   	System.setProperty("webdriver.chrome.driver",constants.ChromeDriver); 
//   	
//   	
//   	
//   	constants.driver = new ChromeDriver();
//   	Thread.sleep(30000);
//   	constants.driver.manage().window().maximize();
   	
   	
   	
   	System.setProperty("webdriver.chrome.driver",constants.ChromeDriver);
	DesiredCapabilities capabilities = DesiredCapabilities.chrome();
	ChromeOptions options = new ChromeOptions();

	options.addArguments("test-type");

	capabilities.setCapability("chrome.binary",	constants.ChromeDriver);
	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	constants.driver = new ChromeDriver(capabilities);
	Thread.sleep(30000);

   }

}
