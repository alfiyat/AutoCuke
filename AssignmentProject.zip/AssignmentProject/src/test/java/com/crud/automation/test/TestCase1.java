package com.crud.automation.test;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.crud.automation.customproperties.BrowserSetup;
import com.crud.automation.customproperties.Constants;

public class TestCase1 {
	
	Constants constants = new Constants();
	BrowserSetup setup = new BrowserSetup();
	
	@BeforeClass
	public void SetUp() throws Exception {
		setup.Chromebrowser(constants);
		constants.driver.get(constants.URL);
	}
	@Test
	public void test()
	{
		System.out.println("hello");
	}
	
	@AfterClass
	public void end() {
		constants.driver.close();
	}
}
